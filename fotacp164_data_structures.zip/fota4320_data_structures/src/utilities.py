"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:  George Fotabong    
ID:        200484320
Email:   fota4320@mylaurier.ca
__updated__ = "2021-06-09"
-------------------------------------------------------
"""
from List_array import List 
from Priority_Queue_array import Priority_Queue
from Queue_array import Queue
from Stack_array import Stack
# Constants
SEP = "-" * 60


def array_to_stack(stack, source):
    """
    -------------------------------------------------------
    Pushes contents of source onto stack. At finish, source is empty.
    Last value in source is at bottom of stack, 
    first value in source is on top of stack.
    Use: array_to_stack(s, a)
    -------------------------------------------------------
    Parameters:
        stack - a Stack object (Stack)
        source - a Python list (list)
    Returns:
        None
    -------------------------------------------------------
    """
    for _ in range(len(source)):
        element = source[-1]
        stack.push(element)    
        del source[-1]
    return


def stack_to_array(stack, target):
    """
    -------------------------------------------------------
    Pops contents of stack into target. At finish, stack is empty.
    Top value of stack is at end of target,
    bottom value of stack is at beginning of target.
    Use: stack_to_array(stack, target)
    -------------------------------------------------------
    Parameters:
        stack - a Stack object (Stack)
        target - a Python list (list)
    Returns:
        None
    -------------------------------------------------------
    """
    while not stack.is_empty():
        target.insert(0, stack.pop())
    return


def stack_test(source):
    """
    -------------------------------------------------------
    Tests the methods of Stack for empty and 
    non-empty stacks using the data in source:
    is_empty, push, pop, peek
    (Testing pop and peek while empty throws exceptions)
    Use: stack_test(source)
    -------------------------------------------------------
    Parameters:
        source - list of data (list of ?)
    Returns:
        None
    -------------------------------------------------------
    """
    
    s = Stack()
    empty = s.is_empty()
    print("Testing is_empty expected result: True the actual result {}".format(empty))
    for i in range(len(source)):
        s.push(source[i])
        peek = s.peek()
        print(peek)
        pop = s.pop()
        print(pop)
    return


def array_to_queue(queue, source):
    """
    -------------------------------------------------------
    Inserts contents of source into queue. At finish, source is empty.
    Last value in source is at rear of queue, 
    first value in source is at front of queue.
    Use: array_to_queue(queue, source)
    -------------------------------------------------------
    Parameters:
        queue - a Queue object (Queue)
        source - a Python list (list)
    Returns:
        None
    -------------------------------------------------------
    """
    for i in range(len(source)):
        element = source[0]
        queue.insert(element)
        del source[0]
    return


def queue_to_array(queue, target):
    """
    -------------------------------------------------------
    Removes contents of queue into target. At finish, queue is empty.
    Front value of queue is at front of target,
    rear value of queue is at end of target.
    Use: queue_to_array(queue, target)
    -------------------------------------------------------
    Parameters:
        queue - a Queue object (Queue)
        target - a Python list (list)
    Returns:
        None
    -------------------------------------------------------
    """
    while not queue.is_empty():
        target.append(queue.remove())
    return


def queue_test(a):
    """
    -------------------------------------------------------
    Tests queue implementation.
    Tests the methods of Queue are tested for both empty and
  non-empty queues using the data in a:
        is_empty, insert, remove, peek, len
    Use: queue_test(a)
    -------------------------------------------------------
    Parameters:
        a - list of data (list of ?)
    Returns:
        None
    -------------------------------------------------------
    """
    q = Queue()
    print("queue contents: ")
    for i in q:
        print(i, end=' ')
    print("\tEmpty? {}".format(q.is_empty()))
    print("elements to insert: {}".format(len(a)))    
    for elem in a:
        q.insert(elem)
    print("queue contents: ")
    for i in q:
        print(i, end=' ')
    print("\tEmpty? {}".format(q.is_empty()))
    top = None
    try:
        top = q.peek()
    except:
        print("Queue is empty")
    print("Top of queue should be same as end of list")
    if q.is_empty():
        print("List empty so no check")
    else:
        top_same = (top == a[0])
        print("Top is same as beginning of list?")
        print("Top: {} Front of list: {}".format(top, a[0]))
        print("Same? {}".format(top_same))
    try:
        print("Remove top of queue")
        popped = q.remove()
        print("Removed value should be same as beginning of list. Same? {}".format(popped == a[0]))
    except:
        print("Removed from an empty queue")
    return


def array_to_pq(pq, source):
    """
    -------------------------------------------------------
    Inserts contents of source into pq. At finish, source is empty.
    Last value in source is at rear of pq, 
    first value in source is at front of pq.
    Use: array_to_pq(pq, source)
    -------------------------------------------------------
    Parameters:
        pq - a Priority_Queue object (Priority_Queue)
        source - a Python list (list)
    Returns:
        None
    -------------------------------------------------------
    """
    for i in range(len(source)):
        element = source[0]
        pq.insert(element)
        del source[0]
    return


def pq_to_array(pq, target):
    """
    -------------------------------------------------------
    Removes contents of pq into target. At finish, pq is empty.
    Highest priority value in pq is at front of target,
    lowest priority value in pq is at end of target.
    Use: pq_to_array(pq, target)
    -------------------------------------------------------
    Parameters:
        pq - a Priority_Queue object (Priority_Queue)
        target - a Python list (list)
    Returns:
        None
    -------------------------------------------------------
    """
    while not pq.is_empty():
        target.append(pq.remove())
    return


def priority_queue_test(a):
    """
    -------------------------------------------------------
    Tests priority queue implementation.
    Use: pq_test(a)
    -------------------------------------------------------
    Parameters:
        a - list of data (list of ?)
    Returns:
        the methods of Priority_Queue are tested for both empty and 
        non-empty priority queues using the data in a:
        is_empty, insert, remove, peek
    -------------------------------------------------------
    """
    pq = Priority_Queue()
    print("priority queue: ")
    for i in pq:
        print(i, end=' ')
    print("\tEmpty? {}".format(pq.is_empty()))
    print("elements to insert: {}".format(len(a)))    
    for elem in a:
        pq.insert(elem)
    print("priority queue: ")
    for i in pq:
        print(i, end=' ')
    print("\tEmpty? {}".format(pq.is_empty()))
    top = None
    try:
        top = pq.peek()
    except:
        print("Peeked at an empty priority queue")
    print("Top of priority queue should be same as beginning of list")
    highest_priority = 0
    if pq.is_empty():
        print("List is empty")
    else:
        for i in range(len(a)):
            if a[i] < a[highest_priority]:
                highest_priority = i
        priority_same = (top == a[highest_priority])
        print("Top: \n{}\tFront of list: \n{}".format(top, a[highest_priority]))
        print("Same? {}".format(priority_same))
        popped = pq.remove()
        print("Removed value from pq: {} Lowest value of list: {}".format(popped, a[highest_priority]))
        print("Removed value should be same as lowest value of list. Same? {}".format(popped == a[highest_priority]))
    return


def array_to_list(llist, source):
    """
    -------------------------------------------------------
    Appends contests of source to llist. At finish, source is empty.
    Last element in source is at rear of llist,
    first element in source is at front of llist.
    Use: array_to_list(llist, source)
    -------------------------------------------------------
    Parameters:
        llist - a List object (List)
        source - a Python list (list)
    Returns:
        None
    -------------------------------------------------------
    """
    while len(source) > 0:
        llist.append(source.pop(0))
    return


def list_to_array(llist, target):
    """
    -------------------------------------------------------
    Removes contents of llist into target. At finish, llist is empty.
    Front element of llist is at front of target,
    rear element of llist is at rear of target.
    Use: list_to_array(llist, target)
    -------------------------------------------------------
    Parameters:
        llist - a List object (List)
        target - a Python list (list)
    Returns:
        None
    -------------------------------------------------------
    """
    while not llist.empty():
        target.append(llist.pop())
    return


def list_test(source):
    """
    -------------------------------------------------------
    Tests List implementation.
    The methods of List are tested for both empty and
    non-empty lists using the data in source
    Use: list_test(source)
    -------------------------------------------------------
    Parameters:
        source - list of data (list of ?)
    Returns:
        None
    -------------------------------------------------------
    """
    lst = List()

    # tests for the List methods go here
    # print the results of the method calls and verify by hand
    key = source[0]
    print("Empty list: ")
    print(" Size: {}".format(len(lst)))
    print(" Empty: {}".format(lst.empty()))
    print(" Key: {}".format(key))
    print(" Key in list: {}".format(key in lst))
    print(SEP)
    print('Fill the list.')
    array_to_list(lst, source)
    print(SEP)
    for v in lst:
        print(v)
    print()
    print(" Max: {}".format(max(lst)))
    print()
    print(" Min: {}".format(min(lst)))
    print()
    print('Using Key Value')
    print(" Key: {}".format(key))
    print()
    print(" Key in list: {}".format(key in lst))
    print()
    print(" Key count {} times".format(lst.count(key)))
    print()
    print(" Find value: {}".format(lst.find(key)))
    print()
    print("Removing a node:")
    print(lst.remove(key))
    
    return
