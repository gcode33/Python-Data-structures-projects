"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:  George Fotabong    
ID:        200484320
Email:   fota4320@mylaurier.ca
__updated__ = "2021-05-27"
-------------------------------------------------------
"""
from Food import Food


def get_food():
    """-------------------------------------------------------
       Creates a food object by requesting data from a user.
       Use: f = get_food()
       -------------------------------------------------------
       Returns:food - a completed food object (Food).
       -------------------------------------------------------
       """
    name = input("Name: ")
    s = Food.origins()
    origin = int(input(s + ':'))
    is_vegetarian = input("Vegetarian (Y/N): ")
    if is_vegetarian.upper() == 'Y':
        is_vegetarian = True
    elif is_vegetarian.upper() == 'N':
        is_vegetarian = False
        
    calories = int(input("Calories: "))
    food = Food(name, origin, is_vegetarian, calories)
    print(food)
    return food


def read_food(line):
    """-------------------------------------------------------
    Creates and returns a food object from a line of string data.
    Use: f = read_food(line)
    -------------------------------------------------------
    Parameters:line - a vertical bar-delimited line of food data in the formatname|origin|is_vegetarian|calories (str)
    Returns:food - contains the data from line (Food)
    -------------------------------------------------------
    """
    line = line.split("|")
    name = line[0]
    origin = int(line[1])
    if line[2] == "True":
        is_vegetarian = True
    else:
        is_vegetarian = False
    calories = int(line[3])
    food = Food(name, origin, is_vegetarian, calories)
    return food


def read_foods(fv):
    """
    --------------------------------------------------------
    Reads a file of food strings into a list of food objects
    use: foods1  = read_foods(fv)
    --------------------------------------------------------
    parameters:
        file_variable - a file of food data (file)
    returns:
        foods- a list of food objects(list of food)
    ----------------------------------------------------------
    """
    fv.seek(0)
    foods = []
    line = fv.readline()
    while line != "":
        food = read_food(line)
        foods.append(food)
        line = fv.readline()
    return foods


def write_foods(fv1, foods):
    """--------------------------------------------------------------------------------
    Writes a list of food objects to a file.file_variable contains 
    the objects in foods as strings in the formatname|origin|is_vegetarian|caloriesUse: 
    write_foods(fv1, foods)
    -----------------------------------------------------------------------------------
    Parameters:file_variable - an open file of food data 
    (file)foods - a list of Food objects (list of Food)Returns:
    None (imperative programming) (functional programming)
    -------------------------------------------------------------------------------------
    """
    for food in foods:
        food.write(fv1)
    return


def get_vegetarian(foods2):
    """-------------------------------------------------------
    Creates a list of vegetarian foods.
    Use: v = get_vegetarian(foods)
    -------------------------------------------------------
    Parameters:foods - a list of Food objects (list of Food)Returns:veggies - 
    Food objects from foods that are vegetarian (list of Food)
    -------------------------------------------------------
    """
    veggies = []
    for food in foods2:
        if food.is_vegetarian:
            veggies.append(food)
    return veggies


def by_origin(foods, origin):
    """
    -------------------------------------------------------
    Creates a list of foods by origin.
    foods is unchanged.
    Use: v = by_origin(foods, origin)
    -------------------------------------------------------
    Parameters:
        foods - a list of Food objects (list of Food)
        origin - a food origin (int)
    Returns:
        origins - Food objects from foods that are of a particular origin (list of Food)
    -------------------------------------------------------
    """
    Food.origins()
    origins = []
    for i in range(0, len(foods)):
        if foods[i].origin == origin:
            origins.append(foods[i])
    return origins


def average_calories(foods):
    """
    -------------------------------------------------------
    Determines the average calories in a list of foods.
    foods is unchanged.
    Use: avg = average_calories(foods)
    -------------------------------------------------------
    Parameters:
        foods - a list of Food objects (list of Food)
    Returns:
        avg - average calories in all Food objects of foods (int)
    -------------------------------------------------------
    """
    total = 0
    for x in foods:
        total += x.calories
    avg = total // len(foods)
    return avg


def calories_by_origin(foods, origin):
    """
    -------------------------------------------------------
    Determines the average calories in a list of foods.
    foods is unchanged.
    Use: a = calories_by_origin(foods, origin)
    -------------------------------------------------------
    Parameters:
        foods - a list of Food objects (list of Food)
        origin - the origin of the Food objects to find (int)
    Returns:
        avg - average calories for all Foods of the requested origin (int)
    -------------------------------------------------------
    """
    
    total = 0
    cnt = 0
    for food in foods:
        if food.origin == origin:
            total += food.calories
            cnt += 1
    if cnt > 0:
        avg = total / cnt
    else:
        avg = 0
    return avg


def food_table(foods):
    """
    -------------------------------------------------------
    Prints a formatted table of foods, sorted by name.
    foods is unchanged.
    Use: food_table(foods)
    -------------------------------------------------------
    Parameters:
        foods - a list of Food objects (list of Food)
    Returns:
        None
    -------------------------------------------------------
    """
    print("food                origin        vegetarian    calories")
    print("------------------- ------------  ------------  --------")
    for i in foods:
        print("{:<35} {:<12} {:10} {:<8}".format(i.name, i.origin, str(i.is_vegetarian), i.calories))
    return


def food_search(foods, origin, max_cals, is_veg):
    """
    -------------------------------------------------------
    Searches for foods that fit certain conditions.
    foods is unchanged.
    Use: results = food_search(foods, origin, max_cals, is_veg)
    -------------------------------------------------------
    Parameters:
        foods - a list of Food objects (list of Food)
        origin - the origin of the food; if -1, accept any origin (int)
        max_cals - the maximum calories for the food; if 0, accept any calories value (int)
        is_veg - whether the food is vegetarian or not; if False accept any food (boolean)
    Returns:
        result - a list of foods that fit the conditions (list of Food)
    -------------------------------------------------------
    """
    assert origin in range (-1, len(Food.ORIGIN))
    result = []
    for i in foods:
        if origin == i.origin:
            if max_cals >= i.calories or max_cals == 0:
                if is_veg == False:
                    result.append(i)
    return result
