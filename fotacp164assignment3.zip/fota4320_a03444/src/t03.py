"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:  George Fotabong    
ID:        200484320
Email:   fota4320@mylaurier.ca
__updated__ = "2021-06-03"
-------------------------------------------------------
"""
from functions import is_palindrome_stack
string = str(input("input a word to check: "))
palindrome = is_palindrome_stack(string)
print(palindrome)
