"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:  George Fotabong    
ID:        200484320
Email:   fota4320@mylaurier.ca
__updated__ = "2021-06-03"
-------------------------------------------------------
"""
from copy import deepcopy
from enum import Enum

from Stack_array import Stack


def stack_combine(source1, source2):
    """
    -------------------------------------------------------
    Combines two source stacks into a target stack. 
    When finished, the contents of source1 and source2 are interlaced 
    into target and source1 and source2 are empty.
    Use: target = stack_combine(source1, source2)
    -------------------------------------------------------
    Parameters:
        source1 - a stack (Stack)
        source2 - another stack (Stack)
    Returns:
        target - the contents of the source1 and source2
            are interlaced into target (Stack)
    -------------------------------------------------------
    """
    # Determine which stack is the shortest, going to loop over that
    # shortest_stack = source2 if len(source1) > len(source2) else source1
    shortest_stack = None
    other_stack = None
    if len(source1) > len(source2):
        shortest_stack = source2
        other_stack = source1
    else:
        shortest_stack = source1
        other_stack = source2
        
    target = Stack()
    
    # Loop and append until shortest stack is empty
    while not shortest_stack.is_empty():
        val1 = shortest_stack.pop()
        val2 = other_stack.pop()
        target.push(val1)
        target.push(val2)
        
    # Handle the rest of the elements in the longer stack
    for element in other_stack:
        target.push(element)
    return


def combine(self, source1, source2):
        """
        -------------------------------------------------------
        Combines two source stacks into the current target stack. 
        When finished, the contents of source1 and source2 are interlaced 
        into target and source1 and source2 are empty.
        Use: target.combine(source1, source2)
        -------------------------------------------------------
        Parameters:
            source1 - an array-based stack (Stack)
            source2 - an array-based stack (Stack)
        Returns:
            None
        -------------------------------------------------------
        """
        shortest_stack = None
        other_stack = None
        if len(source1._values) > len(source2._values):
            shortest_stack = source2
            other_stack = source1
        else:
            shortest_stack = source1
            other_stack = source2
            
        while len(shortest_stack._values) > 0:
            val1 = shortest_stack._values[-1]
            val2 = other_stack._values[-1]
            self._values.append(deepcopy(val1))
            self._values.append(deepcopy(val2))
            del shortest_stack._values[-1]
            del other_stack._values[-1]
            
        for element in other_stack._values:
            self._values.append(deepcopy(element))
            del other_stack._values[-1]
        return


def is_palindrome_stack(string):
    """
    -------------------------------------------------------
    Determines if string is a palindrome. Ignores case, spaces, and
    punctuation in string.
    Use: palindrome = is_palindrome_stack(string)
    -------------------------------------------------------
    Parameters:
        string - a string (str)
    Returns:
        palindrome - True if string is a palindrome, False otherwise (bool)
    -------------------------------------------------------
    """
    s = Stack()
    palindrome = True
    
    CHARACTERS = "abcdefghijklmnopqrstuvwxyz"
    
    if not len(string) % 2 == 0:
        mid = len(string) // 2 + 1
    else:
        mid = len(string) // 2
    
    char_index = 0
    while palindrome:
        char = string[char_index]
        
        if char in CHARACTERS:
            if char_index < mid:  # First half of string
                pass
        
        char_index += 1
    
    return palindrome


OPERATORS = "+-*/"


def postfix(string):
    """
    -------------------------------------------------------
    Evaluates a postfix expression.
    Use: answer = postfix(string)
    -------------------------------------------------------
    Parameters:
        string - the postfix string to evaluate (str)
    Returns:
        answer - the result of evaluating string (float)
    -------------------------------------------------------
    """
    s = Stack()
    
    expression = string.split(" ")  # Split on spaces
    
    for char in expression:
        if char in OPERATORS:
            # Order that we pop is important
            operand2 = s.pop()
            operand1 = s.pop()
            
            if char == OPERATORS[0]:  # Addition
                value = operand1 + operand2
            elif char == OPERATORS[1]:  # Subtraction
                value = operand1 - operand2
            elif char == OPERATORS[-2]:  # Multiplication
                value = operand1 * operand2
            elif char == OPERATORS[-1]:  # Division, do not have to worry about division by zero
                value = operand1 / operand2
            s.push(value)
        else:  # Dealing with a numeric value
            s.push(int(char))
    
    answer = s.pop()  # Answer should be the only thing left in the stack
    return answer


MIRRORED = Enum('MIRRORED',
                {'IS_MIRRORED': "is a mirror", 'TOO_MANY_LEFT': "too many characters in L",
                 'TOO_MANY_RIGHT': "too many characters in R", 'MISMATCHED': "L and R don't match",
                 'INVALID_CHAR': "invalid character", 'NOT_MIRRORED': "no mirror character"})


def is_mirror_stack(string, valid_chars, m):
    """
    -------------------------------------------------------
    Determines if string is a mirror of characters in valid_chars around the pivot m.
    A mirror is of the form LmR, where L is the reverse of R, and L and R
    contain only characters in valid_chars.
    Use: mirror = is_mirror_stack(string, valid_chars, m)
    -------------------------------------------------------
    Parameters:
        string - a string (str)
        valid_chars - a string of valid characters (str)
        m - the mirror pivot string (str - one character not in valid_chars)
    Returns:
        mirror - the state of the string (Enum MIRRORED)
    -------------------------------------------------------
    """
    assert m not in valid_chars, \
        "cannot use '{}' as the mirror character".format(m)
        
    is_mirror = True
    stack = Stack()
    n = len(string)
    i = 0
    mirror = MIRRORED.IS_MIRRORED
    left = 0
    right = 0
    
    while is_mirror and i < n and string[i] != m:
    
        if string[i] in valid_chars:
            stack.push(string[i])
        
        else:
            is_mirror = False
            mirror = MIRRORED.INVALID_CHAR
        
        i += 1
        left += 1
        
        if left == len(string) and is_mirror:
            is_mirror = False
            mirror = MIRRORED.NOT_MIRRORED
        
        left = 0
        i += 1
    
    if is_mirror:
        while i < n and not (stack.is_empty()) and is_mirror:
            c = stack.pop()
            if string[i] != c:
                is_mirror = False
                mirror = MIRRORED.MISMATCHED
    
    elif string[i] == c:
        right += 1
        i += 1
    
    if stack.is_empty() and i < n:
        right += 1
    
    if mirror != MIRRORED.MISMATCHED:
        if right > left:
            is_mirror = False
            mirror = MIRRORED.TOO_MANY_RIGHT
    
        elif left > right:
            is_mirror = False
            mirror = MIRRORED.TOO_MANY_LEFT
    
    return mirror
