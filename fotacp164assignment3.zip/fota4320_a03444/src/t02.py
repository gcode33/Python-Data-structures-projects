"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:  George Fotabong    
ID:        200484320
Email:   fota4320@mylaurier.ca
__updated__ = "2021-06-03"
-------------------------------------------------------
"""
from functions import combine
source1 = int(input("enter a set of numbers: "))
source2 = int(input("enter a second set of numbers: "))
target = combine(source1, source2)
print(target)
