"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:  George Fotabong    
ID:        200484320
Email:   fota4320@mylaurier.ca
__updated__ = "2021-06-03"
-------------------------------------------------------
"""
from functions import postfix
string = input("input a postfix expression: ")
answer = postfix(string)
print(answer)
