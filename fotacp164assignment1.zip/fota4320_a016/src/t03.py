"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:  George Fotabong    
ID:        200484320
Email:   fota4320@mylaurier.ca
__updated__ = "2021-01-17"
-------------------------------------------------------
"""
from Food_utilities import by_origin, read_foods, calories_by_origin

fv = open("foods.txt", "r")
foods = read_foods(fv)

origin = int(input("please input an origin number: "))
origins = by_origin(foods, origin)
ac = calories_by_origin(foods, origin)
print("Average calories for that origin is: {}".format(ac))
print()
