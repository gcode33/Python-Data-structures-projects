"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:  George Fotabong    
ID:        200484320
Email:   fota4320@mylaurier.ca
__updated__ = "2021-01-17"
-------------------------------------------------------
"""
from Food_utilities import read_foods, average_calories

fv = open("foods.txt", "r")
foods = read_foods(fv)
fv.close()

ac = average_calories(foods)
print("Average calories for all foods: {}".format(ac))
