"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:  George Fotabong    
ID:        200484320
Email:   fota4320@mylaurier.ca
__updated__ = "2021-01-17"
-------------------------------------------------------
"""
from Food import Food
from Food_utilities import by_origin, read_foods
fv = open("foods.txt", "r")
foods = read_foods(fv)
fv.close()

for origin in range(len(Food.ORIGIN)):
    temp = by_origin(foods, origin)
    print("  origin: {}".format(Food.ORIGIN[origin]))    
    for f in temp:
        print(f)
