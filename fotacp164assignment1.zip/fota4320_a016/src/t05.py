"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:  George Fotabong    
ID:        200484320
Email:   fota4320@mylaurier.ca
__updated__ = "2021-01-17"
-------------------------------------------------------
"""
from Food_utilities import read_foods, food_search
fv = open("foods.txt", "r")
foods = read_foods(fv)

origin = int(input("enter a number for the origin: "))
max_cals = int(input("enter the max amount of calories: "))
veggie = input("enter if the food is vegetarian or not True or false: ")
if veggie == "True":
    is_veg = True
elif veggie == "False":
    is_veg = False
else:
    is_veg = None
results = food_search(foods, origin, max_cals, is_veg)

print(results)
