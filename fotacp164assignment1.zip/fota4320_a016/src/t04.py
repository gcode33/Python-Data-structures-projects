"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:  George Fotabong    
ID:        200484320
Email:   fota4320@mylaurier.ca
__updated__ = "2021-01-17"
-------------------------------------------------------
"""
from Food_utilities import read_foods, food_table

fv = open("foods.txt", "r")
foods = read_foods(fv)

food_table(foods)
print()
