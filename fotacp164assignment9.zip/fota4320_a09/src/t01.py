"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:  George Fotabong    
ID:        200484320
Email:   fota4320@mylaurier.ca
__updated__ = "2021-07-29"
-------------------------------------------------------
"""
from Hash_Set_array import Hash_Set
from functions import insert_words, comparison_total

print("Using array-based list Hash_Set")

fv = open('gibbon.txt', 'r')
hs = Hash_Set(20)

insert_words(fv, hs)
total, max_word = comparison_total(hs)

print("\nTotal Comparisons: {:,}".format(total))
print("Word with max comparisons: {}: {:,}".format(max_word.word, max_word.comparisons))
